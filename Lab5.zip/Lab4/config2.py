# 1. Selected Features

FEATURES=  ['Pclass', 'Sex', 'Age', 'SibSp', 'Embarked']

# 2. Variables a eliminar

DROP_VAR=  ['PassengerId', 'Survived', 'Name', 'Parch', 'Ticket', 'Fare', 'Cabin']

# 3.Análisis y tratamiento de Nulos

IMP_FLOAT=  ['Age']
DROP_FLOAT=  []
IMP_INT=  []
DROP_INT=  []
IMP_OBJ=  ['Embarked']
DROP_OBJ=  []
DROP_OBJ2=  []

# 4. Variables para transformación Logarítmica

BINRZ_VAR=  []
LOGR_VAR=  ['Age']

# 5.Codificación de variables categóricas

COD_DICT_OBJ=  ['Sex', 'Embarked']
COD_OBJ=  []